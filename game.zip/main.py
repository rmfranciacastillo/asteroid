import pygame
from constants import SCREEN_WIDTH, SCREEN_HEIGHT
from logger import log_state
from player import Player 

def main():
    print(f"Starting Asteroids")
    print(f"Screen width: {SCREEN_WIDTH}")
    print(f"Screen height: {SCREEN_HEIGHT}")

    pygame.init()
    screen = pygame.display.set_mode(
        (SCREEN_WIDTH, SCREEN_HEIGHT)
    )

    player = Player(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2)

    clock = pygame.time.Clock()
    dt:float = 0.0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return 
        
        log_state()
        pygame.Surface.fill(screen, (0,0,0))
        pygame.display.flip()

        dt = clock.tick(60) / 1000

        player.draw(screen)
        

if __name__ == "__main__":
    main()
